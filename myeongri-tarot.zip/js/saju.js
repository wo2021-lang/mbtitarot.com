// ============================================================
// 명리 타로 - 사주팔자 계산 엔진 (절기 기반 정밀 버전)
// solar-terms.js 의존
// ============================================================

const CHEONGAN = ['갑','을','병','정','무','기','경','신','임','계'];
const JIJI     = ['자','축','인','묘','진','사','오','미','신','유','술','해'];
const ANIMALS  = ['쥐','소','호랑이','토끼','용','뱀','말','양','원숭이','닭','개','돼지'];

const OHENG_OF_CHEONGAN = ['목','목','화','화','토','토','금','금','수','수'];
const YINYANG_OF_CHEONGAN = ['양','음','양','음','양','음','양','음','양','음'];

const OHENG_OF_JIJI = ['수','토','목','목','토','화','화','토','금','금','토','수'];
const YINYANG_OF_JIJI = ['양','음','양','음','양','음','양','음','양','음','양','음'];

const OHENG_COLORS = {
    '목': { main: '#2d8a4e', light: '#4ade80', dark: '#166534', name: 'Wood' },
    '화': { main: '#dc2626', light: '#f87171', dark: '#991b1b', name: 'Fire' },
    '토': { main: '#b45309', light: '#fbbf24', dark: '#78350f', name: 'Earth' },
    '금': { main: '#9ca3af', light: '#e5e7eb', dark: '#4b5563', name: 'Metal' },
    '수': { main: '#2563eb', light: '#60a5fa', dark: '#1e3a8a', name: 'Water' }
};

const OHENG_SYMBOLS = {
    '목': '木', '화': '火', '토': '土', '금': '金', '수': '水'
};

// 오행 생극 관계
const PRODUCES = { '목':'화', '화':'토', '토':'금', '금':'수', '수':'목' };
const OVERCOMES = { '목':'토', '토':'수', '수':'화', '화':'금', '금':'목' };

// 육친
const YUKCHINS = ['비견','겁재','식신','상관','편재','정재','편관','정관','편인','정인'];

function getYukchin(dayStemIdx, targetStemIdx) {
    const dayOheng = OHENG_OF_CHEONGAN[dayStemIdx];
    const dayYY = YINYANG_OF_CHEONGAN[dayStemIdx];
    const targetOheng = OHENG_OF_CHEONGAN[targetStemIdx];
    const targetYY = YINYANG_OF_CHEONGAN[targetStemIdx];
    const samePolarity = (dayYY === targetYY);

    if (dayOheng === targetOheng) return samePolarity ? '비견' : '겁재';
    if (PRODUCES[dayOheng] === targetOheng) return samePolarity ? '식신' : '상관';
    if (OVERCOMES[dayOheng] === targetOheng) return samePolarity ? '편재' : '정재';
    if (OVERCOMES[targetOheng] === dayOheng) return samePolarity ? '편관' : '정관';
    if (PRODUCES[targetOheng] === dayOheng) return samePolarity ? '편인' : '정인';
    return '비견';
}

// ======== 년주 계산 (입춘 기준) ========
function getYearPillar(year, month, day) {
    const sajuYear = getSajuYear(year, month, day);
    const stemIdx = ((sajuYear - 4) % 10 + 10) % 10;
    const branchIdx = ((sajuYear - 4) % 12 + 12) % 12;
    return { stem: stemIdx, branch: branchIdx, sajuYear: sajuYear };
}

// ======== 월주 계산 (절기 기준) ========
function getMonthPillar(year, month, day, yearStemIdx) {
    const monthInfo = getSajuMonthBranch(year, month, day);
    const branchIdx = monthInfo.branch;

    // 월간 계산: 년간에 따른 인월(寅月) 시작 천간
    // 갑/기→병(2), 을/경→무(4), 병/신→경(6), 정/임→임(8), 무/계→갑(0)
    const monthStemStart = ((yearStemIdx % 5) * 2 + 2) % 10;
    const monthOffset = ((branchIdx - 2) + 12) % 12;
    const stemIdx = (monthStemStart + monthOffset) % 10;

    return {
        stem: stemIdx,
        branch: branchIdx,
        termName: monthInfo.termName
    };
}

// ======== 일주 계산 (JDN 기반 정밀 계산) ========
// 공식: sexagenary_index = (JDN + 49) % 60, 0 = 甲子
// stem = (JDN + 9) % 10,  branch = (JDN + 1) % 12
// 검증: 2000-01-01 (JDN=2451545) = 무오(戊午), 2024-01-01 = 갑자(甲子)
function getDayPillar(year, month, day) {
    const jdn = getJDN(year, month, day);
    const stemIdx = (jdn + 9) % 10;
    const branchIdx = (jdn + 1) % 12;
    return { stem: stemIdx, branch: branchIdx };
}

// ======== 시주 계산 ========
function getHourBranch(hour) {
    if (hour === 23 || hour === 0) return 0; // 자시
    return Math.floor((hour + 1) / 2);
}

function getHourPillar(dayStemIdx, hour) {
    const branchIdx = getHourBranch(hour);
    // 시간 천간: 일간에 따른 자시(子時) 시작
    // 갑/기→갑(0), 을/경→병(2), 병/신→무(4), 정/임→경(6), 무/계→임(8)
    const hourStemStarts = [0, 2, 4, 6, 8];
    const startStem = hourStemStarts[dayStemIdx % 5];
    const stemIdx = (startStem + branchIdx) % 10;
    return { stem: stemIdx, branch: branchIdx };
}

// ======== 오행 분석 ========
function analyzeOheng(pillars) {
    const count = { '목': 0, '화': 0, '토': 0, '금': 0, '수': 0 };
    pillars.forEach(p => {
        count[OHENG_OF_CHEONGAN[p.stem]]++;
        count[OHENG_OF_JIJI[p.branch]]++;
    });
    return count;
}

// ======== 전체 사주 계산 ========
function calculateSaju(year, month, day, hour) {
    const yearP = getYearPillar(year, month, day);
    const monthP = getMonthPillar(year, month, day, yearP.stem);
    const dayP = getDayPillar(year, month, day);
    const hourP = getHourPillar(dayP.stem, hour);

    const pillars = [yearP, monthP, dayP, hourP];
    const ohengCount = analyzeOheng(pillars);

    const yukchins = {
        year: getYukchin(dayP.stem, yearP.stem),
        month: getYukchin(dayP.stem, monthP.stem),
        day: '본인',
        hour: getYukchin(dayP.stem, hourP.stem)
    };

    const sortedOheng = Object.entries(ohengCount).sort((a, b) => b[1] - a[1]);

    return {
        pillars,
        pillarNames: ['년주', '월주', '일주', '시주'],
        ohengCount,
        yukchins,
        strongest: sortedOheng[0],
        weakest: sortedOheng[sortedOheng.length - 1],
        dayMaster: {
            stem: dayP.stem,
            oheng: OHENG_OF_CHEONGAN[dayP.stem],
            yinyang: YINYANG_OF_CHEONGAN[dayP.stem]
        },
        sajuYear: yearP.sajuYear,
        monthTerm: monthP.termName
    };
}
