// ============================================================
// 명리 타로 - 메인 앱 로직
// ============================================================

let currentSaju = null;
let currentName = '';
let currentBirthInfo = {};

// 앱 초기화
document.addEventListener('DOMContentLoaded', () => {
    showScreen('landing');
    initParticles();
});

// 화면 전환
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const screen = document.getElementById(screenId);
    if (screen) {
        screen.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'instant' });
    }
}

// 시작 버튼
function startReading() {
    showScreen('input-screen');
}

// 사주 계산 실행
function calculateAndShow() {
    const name = document.getElementById('user-name').value.trim();
    const birthDate = document.getElementById('birth-date').value;
    const birthHour = document.getElementById('birth-hour').value;
    const gender = document.querySelector('input[name="gender"]:checked');

    if (!name) { showToast('이름을 입력해주세요'); return; }
    if (!birthDate) { showToast('생년월일을 선택해주세요'); return; }
    if (birthHour === '') { showToast('태어난 시간을 선택해주세요'); return; }
    if (!gender) { showToast('성별을 선택해주세요'); return; }

    const [year, month, day] = birthDate.split('-').map(Number);
    currentName = name;
    currentBirthInfo = { year, month, day, hour: parseInt(birthHour), gender: gender.value };

    // 로딩 연출
    showLoadingThenResult();
}

// 로딩 연출 후 결과 표시
function showLoadingThenResult() {
    showScreen('loading-screen');
    const loadingText = document.getElementById('loading-text');
    const messages = [
        '사주를 분석하고 있습니다...',
        '천간과 지지를 배열합니다...',
        '오행의 균형을 살피고 있습니다...',
        '운명의 카드를 준비합니다...'
    ];

    let i = 0;
    const interval = setInterval(() => {
        i++;
        if (i < messages.length) {
            loadingText.textContent = messages[i];
        }
    }, 700);

    // 실제 계산 (빠르지만 연출을 위해 딜레이)
    setTimeout(() => {
        clearInterval(interval);
        try {
            const { year, month, day, hour, gender } = currentBirthInfo;
            currentSaju = calculateSaju(year, month, day, hour);
            showSajuResult();
        } catch (e) {
            console.error('사주 계산 오류:', e);
            showErrorToast('사주 계산 오류: ' + e.message);
            showScreen('input-screen');
        }
    }, 2800);
}

// 사주 결과 표시
function showSajuResult() {
    const saju = currentSaju;
    const { year, month, day, hour, gender } = currentBirthInfo;
    const container = document.getElementById('saju-result-content');

    const genderText = gender === 'male' ? '남' : '여';
    const animal = ANIMALS[saju.pillars[0].branch];

    let html = `
        <div class="result-header">
            <h2>${currentName}님의 사주원국</h2>
            <p class="birth-info">${year}년 ${month}월 ${day}일 ${getHourText(hour)} | ${genderText} | ${animal}띠</p>
            <p class="birth-info-sub">사주년: ${saju.sajuYear}년 (입춘 기준) | 월건: ${saju.monthTerm}</p>
        </div>

        <div class="pillars-container">
    `;

    // 4주 표시 (시-일-월-년 순)
    const pillarIndices = [3, 2, 1, 0];

    pillarIndices.forEach(idx => {
        const p = saju.pillars[idx];
        const stemOheng = OHENG_OF_CHEONGAN[p.stem];
        const branchOheng = OHENG_OF_JIJI[p.branch];
        const yukchin = saju.yukchins[['year', 'month', 'day', 'hour'][idx]];

        html += `
            <div class="pillar">
                <div class="pillar-label">${saju.pillarNames[idx]}</div>
                <div class="pillar-yukchin">${yukchin}</div>
                <div class="pillar-cell stem" style="background: ${OHENG_COLORS[stemOheng].main}15; border-color: ${OHENG_COLORS[stemOheng].main}">
                    <span class="cell-char">${CHEONGAN[p.stem]}</span>
                    <span class="cell-hanja">${CHEONGAN_CARDS[p.stem].hanja}</span>
                    <span class="cell-oheng" style="color:${OHENG_COLORS[stemOheng].main}">${stemOheng}(${OHENG_SYMBOLS[stemOheng]})</span>
                </div>
                <div class="pillar-cell branch" style="background: ${OHENG_COLORS[branchOheng].main}15; border-color: ${OHENG_COLORS[branchOheng].main}">
                    <span class="cell-char">${JIJI[p.branch]}</span>
                    <span class="cell-hanja">${JIJI_CARDS[p.branch].hanja}</span>
                    <span class="cell-oheng" style="color:${OHENG_COLORS[branchOheng].main}">${branchOheng}(${OHENG_SYMBOLS[branchOheng]})</span>
                </div>
            </div>
        `;
    });

    html += `</div>`;

    // 오행 분석 바
    html += `<div class="oheng-analysis"><h3>오행 분석</h3><div class="oheng-bars">`;
    for (const [oh, count] of Object.entries(saju.ohengCount)) {
        const pct = (count / 8) * 100;
        const isEmpty = count === 0;
        html += `
            <div class="oheng-bar-item">
                <span class="oheng-label" style="color: ${OHENG_COLORS[oh].main}">${OHENG_SYMBOLS[oh]} ${oh}</span>
                <div class="oheng-bar-track">
                    <div class="oheng-bar-fill" style="width: ${pct}%; background: ${OHENG_COLORS[oh].main}"></div>
                </div>
                <span class="oheng-count ${isEmpty ? 'oheng-empty' : ''}">${count}${isEmpty ? ' !' : ''}</span>
            </div>
        `;
    }
    html += `</div></div>`;

    // 일간 해석
    const dmCard = CHEONGAN_CARDS[saju.dayMaster.stem];
    html += `
        <div class="day-master-info">
            <div class="dm-symbol">${dmCard.symbol}</div>
            <h3>${dmCard.title}</h3>
            <p class="dm-subtitle">${saju.dayMaster.yinyang}${saju.dayMaster.oheng} · ${CHEONGAN[saju.dayMaster.stem]}(${dmCard.hanja}) 일간</p>
            <p class="dm-desc">${dmCard.description}</p>
            <div class="dm-keywords">
                ${dmCard.keywords.map(k => `<span class="keyword-tag">${k}</span>`).join('')}
            </div>
        </div>
    `;

    // 올해 세운
    const thisYear = new Date().getFullYear();
    const yearStem = ((thisYear - 4) % 10 + 10) % 10;
    const yearBranch = ((thisYear - 4) % 12 + 12) % 12;
    const yearYukchin = getYukchin(saju.dayMaster.stem, yearStem);
    const yearCard = CHEONGAN_CARDS[yearStem];
    const yearAnimalCard = JIJI_CARDS[yearBranch];

    html += `
        <div class="year-fortune">
            <h3>${thisYear}년 세운</h3>
            <div class="year-fortune-row">
                <div class="year-fortune-card">
                    <span class="yf-symbol">${yearCard.symbol}</span>
                    <span class="yf-text">${CHEONGAN[yearStem]}${JIJI[yearBranch]}년</span>
                    <span class="yf-sub">${yearAnimalCard.symbol} ${ANIMALS[yearBranch]}의 해</span>
                </div>
                <div class="year-fortune-detail">
                    <div class="yf-yukchin">
                        <span class="yf-badge">${yearYukchin}</span>의 해
                    </div>
                    <p class="yf-reading">${getYearYukchinReading(yearYukchin)}</p>
                </div>
            </div>
        </div>
    `;

    container.innerHTML = html;

    // 애니메이션
    showScreen('saju-result');
    setTimeout(() => {
        document.querySelectorAll('.pillar').forEach((el, i) => {
            setTimeout(() => el.classList.add('show'), i * 200);
        });
    }, 300);
}

// 세운 육친 해석
function getYearYukchinReading(yukchin) {
    const readings = {
        '비견': '경쟁과 자립의 해. 자신의 힘으로 일어서는 시기입니다. 동업이나 경쟁 상황에 주의하세요.',
        '겁재': '협력과 갈등이 공존하는 해. 재물 관리에 신중해야 하며, 보증이나 투자에 주의하세요.',
        '식신': '창조와 풍요의 해. 재능을 마음껏 발휘할 수 있으며, 먹고 즐기는 복이 있습니다.',
        '상관': '변화와 도전의 해. 기존 틀을 깨고 새로운 시도를 하기 좋으나, 말조심이 필요합니다.',
        '편재': '재물과 기회의 해. 투자나 사업에서 큰 기회가 올 수 있습니다. 과감함이 필요합니다.',
        '정재': '안정적 수입의 해. 꾸준한 노력이 정직하게 보상받는 시기입니다.',
        '편관': '도전과 시련의 해. 힘든 시기지만 이를 통해 한 단계 크게 성장합니다.',
        '정관': '승진과 인정의 해. 사회적 위치가 높아지고 책임도 커지는 시기입니다.',
        '편인': '학습과 변화의 해. 새로운 분야를 배우거나 자격증 취득에 좋습니다.',
        '정인': '지혜와 도움의 해. 귀인이 나타나 길을 열어주며, 학업운이 좋습니다.'
    };
    return readings[yukchin] || '';
}

// 주제 선택 화면
function showTopicSelect() {
    document.getElementById('topic-user-name').textContent = `${currentName}님, 알고 싶은 운세를 선택하세요`;
    showScreen('topic-screen');
}

// 점괘 보기
function viewReading(topic) {
    if (!currentSaju) return;

    // 점괘 로딩 연출
    showScreen('loading-screen');
    const loadingText = document.getElementById('loading-text');
    loadingText.textContent = `${topic} 카드를 뽑고 있습니다...`;

    setTimeout(() => {
        loadingText.textContent = '카드의 의미를 해석합니다...';
    }, 800);

    setTimeout(() => {
        showReadingResult(topic);
    }, 1600);
}

function showReadingResult(topic) {
    const spread = generateSpread(currentSaju, topic);
    const container = document.getElementById('reading-content');

    let html = `
        <div class="reading-header">
            <span class="reading-icon">${spread.template.icon}</span>
            <h2>${spread.template.title}</h2>
            <p>${currentName}님의 ${spread.template.subtitle}</p>
        </div>

        <div class="card-spread">
    `;

    // 카드 3장 표시
    spread.cards.forEach((card, idx) => {
        const stemColor = OHENG_COLORS[card.cheongan.element];

        html += `
            <div class="tarot-card-wrapper" style="animation-delay: ${idx * 0.4}s">
                <div class="card-position-label">${card.position}</div>
                <div class="tarot-card" onclick="flipCard(this)" style="--card-color: ${stemColor.main}; --card-color-light: ${stemColor.light}; --card-color-dark: ${stemColor.dark}">
                    <div class="card-inner">
                        <div class="card-front">
                            <div class="card-pattern"></div>
                            <div class="card-center-symbol">☯</div>
                            <div class="card-subtitle">명리타로</div>
                        </div>
                        <div class="card-back">
                            <div class="card-top-info">
                                <span class="card-element-badge" style="background: ${stemColor.main}">${card.cheongan.element}</span>
                                <span class="card-pillar-badge">${card.pillarName}</span>
                            </div>
                            <div class="card-symbol">${card.cheongan.symbol}</div>
                            <h3 class="card-title">${card.cheongan.title}</h3>
                            <div class="card-hanja">${card.cheongan.hanja}</div>
                            <div class="card-divider"></div>
                            <div class="card-animal-symbol">${card.jiji.symbol}</div>
                            <div class="card-animal-name">${card.jiji.title}</div>
                            <div class="card-keywords">
                                ${card.cheongan.keywords.slice(0, 2).map(k => `<span>${k}</span>`).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });

    html += `</div>`;

    // 해석
    html += `<div class="reading-interpretation">`;
    html += `<h3>${spread.template.icon} 점사 해석</h3>`;
    spread.readings.forEach((reading, idx) => {
        html += `<div class="reading-paragraph" style="animation-delay: ${1.5 + idx * 0.3}s">
            <p>${reading}</p>
        </div>`;
    });
    html += `</div>`;

    // 카드 요약
    html += `
        <div class="reading-summary">
            <h4>카드 요약</h4>
            <div class="summary-cards">
    `;
    spread.cards.forEach(card => {
        html += `
            <div class="summary-card-item">
                <span class="sci-position">${card.position}</span>
                <span class="sci-name">${card.cheongan.symbol} ${card.cheongan.title}</span>
                <span class="sci-element" style="color:${OHENG_COLORS[card.cheongan.element].main}">${card.cheongan.element}</span>
            </div>
        `;
    });
    html += `</div></div>`;

    container.innerHTML = html;
    showScreen('reading-screen');

    // 카드 자동 뒤집기 애니메이션
    setTimeout(() => {
        document.querySelectorAll('.tarot-card').forEach((card, i) => {
            setTimeout(() => card.classList.add('flipped'), 800 + i * 600);
        });
    }, 500);
}

function flipCard(el) {
    el.classList.toggle('flipped');
}

// 공유 기능
function shareResult() {
    const saju = currentSaju;
    const { year, month, day } = currentBirthInfo;
    const dm = CHEONGAN_CARDS[saju.dayMaster.stem];

    const text = `☯ 명리타로 - ${currentName}님의 사주원국\n\n` +
        `생년월일: ${year}.${month}.${day}\n` +
        `사주: ${saju.pillars.map((p,i) => CHEONGAN[p.stem]+JIJI[p.branch]).join(' ')}\n` +
        `일간: ${dm.title} (${saju.dayMaster.yinyang}${saju.dayMaster.oheng})\n` +
        `키워드: ${dm.keywords.join(', ')}\n\n` +
        `나도 명리타로로 운세 보기 →`;

    copyOrShare(text);
}

function shareReading() {
    const topic = document.querySelector('.reading-header h2')?.textContent || '';
    const readings = [];
    document.querySelectorAll('.reading-paragraph p').forEach(p => {
        readings.push(p.textContent);
    });

    const text = `☯ 명리타로 - ${currentName}님의 ${topic}\n\n` +
        readings.slice(0, 3).join('\n\n') +
        `\n\n나도 명리타로로 운세 보기 →`;

    copyOrShare(text);
}

async function copyOrShare(text) {
    // Web Share API 시도
    if (navigator.share) {
        try {
            await navigator.share({ title: '명리타로', text });
            return;
        } catch (e) { /* 사용자 취소 등 */ }
    }
    // 클립보드 복사 폴백
    try {
        await navigator.clipboard.writeText(text);
        showToast('결과가 복사되었습니다!');
    } catch (e) {
        // textarea 폴백
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('결과가 복사되었습니다!');
    }
}

// 네비게이션
function backToTopics() {
    showScreen('topic-screen');
}

function backToResult() {
    showScreen('saju-result');
}

function startOver() {
    currentSaju = null;
    currentName = '';
    currentBirthInfo = {};
    document.getElementById('user-name').value = '';
    document.getElementById('birth-date').value = '';
    document.getElementById('birth-hour').value = '';
    document.querySelectorAll('input[name="gender"]').forEach(r => r.checked = false);
    showScreen('landing');
}

// 시간 텍스트
function getHourText(hour) {
    const siNames = ['자시(23-01)', '축시(01-03)', '인시(03-05)', '묘시(05-07)',
        '진시(07-09)', '사시(09-11)', '오시(11-13)', '미시(13-15)',
        '신시(15-17)', '유시(17-19)', '술시(19-21)', '해시(21-23)'];
    const idx = hour === 23 || hour === 0 ? 0 : Math.floor((hour + 1) / 2);
    return siNames[idx];
}

// 토스트 메시지
function showToast(msg) {
    let toast = document.getElementById('toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast';
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
}

// 에러 토스트 (오래 표시 + 빨간색)
function showErrorToast(msg) {
    let toast = document.getElementById('toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast';
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.borderColor = '#f87171';
    toast.style.color = '#f87171';
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
        toast.style.borderColor = '';
        toast.style.color = '';
    }, 8000);
}

// ======== 오늘의 카드 점 ========
let dailyQuestion = '';
let spreadType = 3;
let currentRound = 0;
let roundDecks = [];
let pickedCards = [];
let currentRoundDeck = [];

function startDailyReading() {
    dailyQuestion = '';
    spreadType = 3;
    currentRound = 0;
    roundDecks = [];
    pickedCards = [];
    currentRoundDeck = [];
    const input = document.getElementById('daily-question-input');
    if (input) input.value = '';
    updateCharCount();
    // 스프레드 기본 선택 (3장)
    document.querySelectorAll('.spread-option').forEach((el, i) => {
        el.classList.toggle('active', i === 1);
    });
    showScreen('daily-question');
}

function selectSpread(type, el) {
    spreadType = type;
    document.querySelectorAll('.spread-option').forEach(o => o.classList.remove('active'));
    el.classList.add('active');
}

function updateCharCount() {
    const input = document.getElementById('daily-question-input');
    const counter = document.getElementById('question-char-count');
    if (input && counter) counter.textContent = input.value.length;
}

// textarea 글자수 카운터
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const input = document.getElementById('daily-question-input');
        if (input) input.addEventListener('input', updateCharCount);
    }, 100);
});

function startShuffle() {
    const input = document.getElementById('daily-question-input');
    dailyQuestion = input ? input.value.trim() : '';
    if (!dailyQuestion) {
        showToast('질문을 입력해주세요');
        return;
    }

    // 스프레드 설정에 따라 덱 준비
    const config = SPREAD_CONFIG[spreadType];
    roundDecks = config.rounds.map(r => shuffleDeck(getDeckByType(r.deckType)));
    pickedCards = [];
    currentRound = 0;

    // 셔플 연출
    showScreen('shuffle-screen');
    renderShuffleAnimation();

    const textEl = document.getElementById('shuffle-text');
    const messages = [
        '카드를 섞고 있습니다...',
        '기운을 느끼고 있습니다...',
        '카드가 준비되었습니다...'
    ];
    let mi = 0;
    const msgInterval = setInterval(() => {
        mi++;
        if (mi < messages.length) textEl.textContent = messages[mi];
    }, 900);

    setTimeout(() => {
        clearInterval(msgInterval);
        showPickRound();
    }, 2700);
}

function renderShuffleAnimation() {
    const container = document.getElementById('shuffle-cards');
    container.innerHTML = '';
    for (let i = 0; i < 7; i++) {
        const card = document.createElement('div');
        card.className = 'shuffle-card';
        card.innerHTML = '<span>☯</span>';
        card.style.animationDelay = `${i * 0.1}s`;
        container.appendChild(card);
    }
}

function showPickRound() {
    const config = SPREAD_CONFIG[spreadType];
    const round = config.rounds[currentRound];
    currentRoundDeck = roundDecks[currentRound];

    // 헤더 업데이트
    const indicator = document.getElementById('pick-round-indicator');
    if (config.rounds.length > 1) {
        indicator.innerHTML = config.rounds.map((r, i) =>
            `<span class="round-dot ${i === currentRound ? 'active' : ''} ${i < currentRound ? 'done' : ''}">${r.icon}</span>`
        ).join('');
        indicator.style.display = 'flex';
    } else {
        indicator.style.display = 'none';
    }

    document.getElementById('pick-title').textContent = `${round.icon} ${round.label}`;
    document.getElementById('pick-subtitle').textContent = round.desc;

    // 카드 그리드 렌더
    const grid = document.getElementById('pick-grid');
    let html = '';
    currentRoundDeck.forEach((card, i) => {
        html += `
            <div class="pick-card" id="pick-card-${i}" onclick="pickCard(${i})">
                <div class="pick-card-inner">
                    <div class="pick-card-back">
                        <span>☯</span>
                        <small>${i + 1}</small>
                    </div>
                </div>
            </div>
        `;
    });
    grid.innerHTML = html;

    // 그리드 열 수 조정
    const count = currentRoundDeck.length;
    if (count <= 12) {
        grid.style.gridTemplateColumns = `repeat(${Math.min(count, 6)}, 1fr)`;
    } else {
        grid.style.gridTemplateColumns = '';  // CSS 기본값 사용
    }

    showScreen('pick-screen');
}

let pickLocked = false;

function pickCard(index) {
    if (pickLocked) return;  // 더블클릭 방지
    pickLocked = true;

    // 이미 이번 라운드에서 선택한 카드가 있으면 해제
    const prevPicked = document.querySelector('.pick-card.picked');
    if (prevPicked) {
        prevPicked.classList.remove('picked');
    }

    // 선택
    document.getElementById(`pick-card-${index}`).classList.add('picked');
    const card = { ...currentRoundDeck[index] };

    // 잠시 후 자동 진행
    setTimeout(() => {
        pickLocked = false;
        try {
            pickedCards.push(card);
            currentRound++;

            const config = SPREAD_CONFIG[spreadType];
            if (currentRound < config.rounds.length) {
                // 다음 라운드
                showPickRound();
            } else {
                // 모든 카드 선택 완료 → 결과
                revealDailyCards();
            }
        } catch (e) {
            console.error('pickCard 오류:', e);
            showErrorToast('카드 선택 오류: ' + e.message);
        }
    }, 600);
}

async function revealDailyCards() {
  try {
    // 카드 배열 검증
    const validCards = pickedCards.filter(c => c != null);
    if (validCards.length === 0) {
        showErrorToast('선택된 카드가 없습니다. 다시 시도해주세요.');
        showScreen('daily-question');
        return;
    }
    // validCards를 이후 모든 곳에서 사용
    pickedCards = validCards;
    const result = generateDailyReading(pickedCards, dailyQuestion, spreadType);
    const container = document.getElementById('daily-result-content');
    const config = SPREAD_CONFIG[spreadType];

    // 카드 HTML 생성
    const cardsHtml = buildCardsHtml(pickedCards, config);

    // AI 키 확인
    const hasAI = !!getAIApiKey();

    if (hasAI) {
        // AI 모드: 로딩 표시 후 AI 점사 생성
        container.innerHTML = `
            <div class="reading-header">
                <span class="reading-icon">🃏</span>
                <h2>${config.name}</h2>
                <p class="daily-question-display">"${escapeHtml(dailyQuestion)}"</p>
            </div>
            <div class="card-spread">${cardsHtml}</div>
            <div class="comprehensive-section ai-loading-section">
                <h3>🔮 AI가 점사를 풀고 있습니다...</h3>
                <div class="ai-loading-anim">
                    <div class="ai-loading-dot"></div>
                    <div class="ai-loading-dot"></div>
                    <div class="ai-loading-dot"></div>
                </div>
                <p class="ai-loading-msg">카드의 기운을 읽고 있어요</p>
            </div>
        `;
        showScreen('daily-result');
        autoFlipCards();

        // AI 호출
        const aiText = await generateAIReading(pickedCards, dailyQuestion, spreadType);

        if (aiText) {
            // AI 성공 → AI 점사 + 카드 사전
            const formatted = aiText
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\n\n/g, '</p><p>')
                .replace(/\n/g, '<br>');

            container.innerHTML = `
                <div class="reading-header">
                    <span class="reading-icon">🃏</span>
                    <h2>${config.name}</h2>
                    <p class="daily-question-display">"${escapeHtml(dailyQuestion)}"</p>
                </div>
                <div class="card-spread">${cardsHtml}</div>
                <div class="comprehensive-section ai-result">
                    <div class="ai-badge">✨ AI 맞춤 점사</div>
                    <div class="comprehensive-text"><p>${formatted}</p></div>
                </div>
                ${buildOhengHtml(pickedCards, result)}
                ${buildDictionaryHtml(pickedCards)}
            `;
            autoFlipCards();
        } else {
            // AI 실패 → 기본 해석으로 폴백
            showToast('AI 점사 생성 실패. 기본 해석을 표시합니다.');
            renderFallbackResult(container, config, cardsHtml, result);
            showScreen('daily-result');
            autoFlipCards();
        }
    } else {
        // 기본 모드: 템플릿 해석
        renderFallbackResult(container, config, cardsHtml, result);
        showScreen('daily-result');
        autoFlipCards();
    }
  } catch (e) {
    console.error('점사 결과 생성 오류:', e);
    showErrorToast('점사 오류: ' + e.message);
    showScreen('daily-question');
  }
}

function buildCardsHtml(cards, config) {
    let html = '';
    cards.forEach((card, idx) => {
        if (!card) return;
        const roundInfo = config.rounds[idx];
        if (!roundInfo) return;
        const color = OHENG_COLORS[card.oheng];
        const isCombo = card.deckType === 'combo';
        const color2 = isCombo ? OHENG_COLORS[card.oheng2] : null;
        const typeBadge = isCombo ? '갑자' : (card.deckType === 'cheongan' ? '천간' : '지지');

        html += `
            <div class="tarot-card-wrapper" style="animation-delay: ${idx * 0.4}s">
                <div class="card-position-label">${roundInfo.icon} ${roundInfo.label}</div>
                <div class="tarot-card" onclick="flipCard(this)" style="--card-color: ${color.main}; --card-color-light: ${color.light}; --card-color-dark: ${color.dark}">
                    <div class="card-inner">
                        <div class="card-front">
                            <div class="card-pattern"></div>
                            <div class="card-center-symbol">☯</div>
                            <div class="card-subtitle">명리타로</div>
                        </div>
                        <div class="card-back">
                            <div class="card-top-info">
                                <span class="card-element-badge" style="background: ${color.main}">${card.oheng}</span>
                                ${isCombo ? `<span class="card-element-badge" style="background: ${color2.main}">${card.oheng2}</span>` : ''}
                                <span class="card-pillar-badge">${typeBadge}</span>
                            </div>
                            <div class="card-symbol">${card.symbol}${isCombo ? card.symbol2 : ''}</div>
                            <h3 class="card-title">${isCombo ? card.displayName : card.title}</h3>
                            <div class="card-hanja">${card.hanja}</div>
                            ${isCombo ? `<div class="card-combo-subtitle">${card.title} + ${card.title2}</div>` : ''}
                            <div class="card-divider"></div>
                            <div class="card-animal-name">${card.char}(${card.oheng}${isCombo ? '/' + card.oheng2 : ''})</div>
                            <div class="card-keywords">
                                ${card.keywords.slice(0, 2).map(k => `<span>${k}</span>`).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    return html;
}

function buildOhengHtml(cards, result) {
    return `
        <div class="reading-interpretation">
            <div class="reading-card-section combination">
                <div class="rcs-header">
                    <span class="rcs-icon">⚖️</span>
                    <span class="rcs-position">오행 조합</span>
                    <span class="rcs-oheng-dots">
                        ${cards.map(c => {
                            let dots = `<span style="color:${OHENG_COLORS[c.oheng].main}">${OHENG_SYMBOLS[c.oheng]}</span>`;
                            if (c.oheng2) dots += `<span style="color:${OHENG_COLORS[c.oheng2].main}">${OHENG_SYMBOLS[c.oheng2]}</span>`;
                            return dots;
                        }).join(' ')}
                    </span>
                </div>
                <p class="rcs-text">${result.ohengAnalysis.text}</p>
            </div>
        </div>
    `;
}

function buildDictionaryHtml(cards) {
    let html = `<div class="card-dictionary-section"><h3>📖 카드 사전</h3>`;
    cards.forEach(card => {
        if (!card) return;
        const info = getCardDictionaryInfo(card);
        const color = OHENG_COLORS[card.oheng];
        html += `
            <details class="card-dict-item">
                <summary style="border-left-color: ${color.main}">
                    <span class="dict-symbol">${card.symbol}${card.symbol2 || ''}</span>
                    <span class="dict-name">${info.name}</span>
                    <span class="dict-toggle">▸</span>
                </summary>
                <div class="dict-content">
                    <p>${info.desc.replace(/\n/g, '</p><p>')}</p>
                    <div class="dict-keywords">${info.keywords.map(k => `<span class="dict-kw">${k}</span>`).join('')}</div>
                </div>
            </details>
        `;
    });
    html += `</div>`;
    return html;
}

function renderFallbackResult(container, config, cardsHtml, result) {
    const formatted = result.comprehensive
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>');

    let cardSections = '';
    result.cardReadings.forEach((r, idx) => {
        const card = pickedCards[idx];
        if (!card) return;
        const color = OHENG_COLORS[card.oheng];
        const cardName = card.deckType === 'combo' ? card.displayName : `${card.char}(${card.hanja})`;
        cardSections += `
            <div class="reading-card-section">
                <div class="rcs-header">
                    <span class="rcs-icon">${r.icon}</span>
                    <span class="rcs-position">${r.label}</span>
                    <span class="rcs-card" style="color: ${color.main}">${card.symbol}${card.symbol2 || ''} ${cardName}</span>
                </div>
                <p class="rcs-text">${r.topicText}</p>
            </div>
        `;
    });

    container.innerHTML = `
        <div class="reading-header">
            <span class="reading-icon">🃏</span>
            <h2>${config.name}</h2>
            <p class="daily-question-display">"${escapeHtml(dailyQuestion)}"</p>
        </div>
        <div class="card-spread">${cardsHtml}</div>
        <div class="comprehensive-section">
            <h3>🔮 종합 점사</h3>
            <div class="comprehensive-text"><p>${formatted}</p></div>
        </div>
        <div class="reading-interpretation">
            <h3>🃏 카드별 해석</h3>
            ${cardSections}
        </div>
        ${buildOhengHtml(pickedCards, result)}
        ${buildDictionaryHtml(pickedCards)}
        <div class="ai-promo">
            <p>✨ <strong>AI 맞춤 점사</strong>를 원하시면 <a href="javascript:openSettings()">설정</a>에서 API 키를 등록하세요</p>
        </div>
    `;
}

function autoFlipCards() {
    setTimeout(() => {
        document.querySelectorAll('.tarot-card').forEach((card, i) => {
            setTimeout(() => card.classList.add('flipped'), 800 + i * 600);
        });
    }, 500);
}

// ======== 설정 ========
function openSettings() {
    const modal = document.getElementById('settings-modal');
    modal.classList.add('show');
    document.getElementById('ai-provider').value = getAIProvider();
    document.getElementById('ai-api-key').value = getAIApiKey();
}

function closeSettings(e) {
    if (e && e.target !== e.currentTarget) return;
    document.getElementById('settings-modal').classList.remove('show');
}

function saveSettings() {
    const key = document.getElementById('ai-api-key').value.trim();
    const provider = document.getElementById('ai-provider').value;
    setAIApiKey(key);
    setAIProvider(provider);
    showToast(key ? 'AI 설정 저장 완료!' : 'API 키가 제거되었습니다');
    closeSettings();
}

function escapeHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ======== 카드 도감 ========
let browseFilterType = 'all';
let browseFilterOheng = 'all';

function showCardBrowse() {
    showScreen('browse-screen');
    browseFilterType = 'all';
    browseFilterOheng = 'all';
    renderBrowseGrid();
}

function filterCards(type, btn) {
    browseFilterType = type;
    document.querySelectorAll('.browse-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    renderBrowseGrid();
}

function filterOheng(oheng, btn) {
    browseFilterOheng = oheng;
    document.querySelectorAll('.oheng-chip').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    renderBrowseGrid();
}

// 60갑자 생성
function generate60Ganji() {
    const combos = [];
    for (let i = 0; i < 60; i++) {
        const stemIdx = i % 10;
        const branchIdx = i % 12;
        combos.push({ stemIdx, branchIdx, index: i + 1 });
    }
    return combos;
}

function renderBrowseGrid() {
    const grid = document.getElementById('browse-grid');

    // 60갑자 조합 모드
    if (browseFilterType === 'combo') {
        renderComboGrid(grid);
        return;
    }

    let cards = [];

    if (browseFilterType === 'all' || browseFilterType === 'cheongan') {
        CHEONGAN_CARDS.forEach((c, i) => {
            cards.push({ ...c, type: 'cheongan', index: i, char: CHEONGAN[i],
                yinyang: YINYANG_OF_CHEONGAN[i], hanja: c.hanja });
        });
    }
    if (browseFilterType === 'all' || browseFilterType === 'jiji') {
        JIJI_CARDS.forEach((c, i) => {
            cards.push({ ...c, type: 'jiji', index: i, char: JIJI[i],
                yinyang: YINYANG_OF_JIJI[i], animal: c.animal });
        });
    }

    if (browseFilterOheng !== 'all') {
        cards = cards.filter(c => c.element === browseFilterOheng);
    }

    grid.className = 'browse-grid';
    let html = '';
    cards.forEach(card => {
        const color = OHENG_COLORS[card.element];
        const typeLabel = card.type === 'cheongan' ? '천간' : '지지';

        html += `
            <div class="browse-card" onclick="openCardModal('${card.type}', ${card.index})">
                <div class="bc-front" style="border-color: ${color.main}; background: ${color.main}10">
                    <div class="bc-symbol">${card.symbol}</div>
                    <div class="bc-char" style="color: ${color.main}">${card.char}</div>
                    <div class="bc-hanja">${card.hanja}</div>
                    <div class="bc-title">${card.title}</div>
                    <div class="bc-meta">
                        <span class="bc-type-badge">${typeLabel}</span>
                        <span class="bc-element-badge" style="background: ${color.main}">${card.element}</span>
                        <span class="bc-yy-badge">${card.yinyang}</span>
                    </div>
                </div>
            </div>
        `;
    });

    if (cards.length === 0) {
        html = '<p style="text-align:center;color:var(--text-dim);grid-column:1/-1;padding:40px 0">해당하는 카드가 없습니다</p>';
    }

    grid.innerHTML = html;
}

function renderComboGrid(grid) {
    const combos = generate60Ganji();
    let filtered = combos;

    if (browseFilterOheng !== 'all') {
        filtered = combos.filter(c =>
            OHENG_OF_CHEONGAN[c.stemIdx] === browseFilterOheng ||
            OHENG_OF_JIJI[c.branchIdx] === browseFilterOheng
        );
    }

    grid.className = 'browse-grid combo-grid';
    let html = '';

    filtered.forEach(combo => {
        const stem = CHEONGAN_CARDS[combo.stemIdx];
        const branch = JIJI_CARDS[combo.branchIdx];
        const stemOheng = OHENG_OF_CHEONGAN[combo.stemIdx];
        const branchOheng = OHENG_OF_JIJI[combo.branchIdx];
        const stemColor = OHENG_COLORS[stemOheng];
        const branchColor = OHENG_COLORS[branchOheng];

        html += `
            <div class="combo-card" onclick="openComboModal(${combo.stemIdx}, ${combo.branchIdx})">
                <div class="cc-top" style="background: linear-gradient(180deg, ${stemColor.dark}, ${stemColor.main}30)">
                    <span class="cc-badge" style="background: ${stemColor.main}">${stemOheng}</span>
                    <span class="cc-num">#${combo.index}</span>
                    <div class="cc-stem-symbol">${stem.symbol}</div>
                    <div class="cc-name">${CHEONGAN[combo.stemIdx]}${JIJI[combo.branchIdx]}</div>
                    <div class="cc-hanja">${stem.hanja}${branch.hanja}</div>
                </div>
                <div class="cc-bottom" style="border-color: ${stemColor.main}40">
                    <div class="cc-branch-symbol">${branch.symbol}</div>
                    <div class="cc-titles">
                        <span class="cc-stem-title">${stem.title}</span>
                        <span class="cc-branch-title">${branch.title}</span>
                    </div>
                    <div class="cc-oheng-pair">
                        <span style="color:${stemColor.main}">${OHENG_SYMBOLS[stemOheng]}</span>
                        <span style="color:var(--text-dim)">+</span>
                        <span style="color:${branchColor.main}">${OHENG_SYMBOLS[branchOheng]}</span>
                    </div>
                </div>
            </div>
        `;
    });

    if (filtered.length === 0) {
        html = '<p style="text-align:center;color:var(--text-dim);grid-column:1/-1;padding:40px 0">해당하는 카드가 없습니다</p>';
    }

    grid.innerHTML = html;
}

function openComboModal(stemIdx, branchIdx) {
    const stem = CHEONGAN_CARDS[stemIdx];
    const branch = JIJI_CARDS[branchIdx];
    const stemOheng = OHENG_OF_CHEONGAN[stemIdx];
    const branchOheng = OHENG_OF_JIJI[branchIdx];
    const stemColor = OHENG_COLORS[stemOheng];
    const branchColor = OHENG_COLORS[branchOheng];
    const stemYY = YINYANG_OF_CHEONGAN[stemIdx];
    const branchYY = YINYANG_OF_JIJI[branchIdx];

    // 오행 관계 분석
    let relation = '';
    if (stemOheng === branchOheng) {
        relation = `같은 ${stemOheng} 오행으로, 기운이 강하게 집중됩니다.`;
    } else if (PRODUCES[stemOheng] === branchOheng) {
        relation = `천간 ${stemOheng}이(가) 지지 ${branchOheng}을(를) 생합니다. 에너지가 자연스럽게 흐르는 조합입니다.`;
    } else if (PRODUCES[branchOheng] === stemOheng) {
        relation = `지지 ${branchOheng}이(가) 천간 ${stemOheng}을(를) 생합니다. 내면의 힘이 외부로 드러나는 조합입니다.`;
    } else if (OVERCOMES[stemOheng] === branchOheng) {
        relation = `천간 ${stemOheng}이(가) 지지 ${branchOheng}을(를) 극합니다. 의지로 환경을 통제하려는 긴장감이 있습니다.`;
    } else if (OVERCOMES[branchOheng] === stemOheng) {
        relation = `지지 ${branchOheng}이(가) 천간 ${stemOheng}을(를) 극합니다. 외부 환경이 내 의지를 시험하는 조합입니다.`;
    }

    const content = document.getElementById('card-modal-content');
    content.innerHTML = `
        <div class="modal-card" style="--mc-color: ${stemColor.main}; --mc-light: ${stemColor.light}; --mc-dark: ${stemColor.dark}">
            <button class="modal-close" onclick="closeCardModal()">&times;</button>

            <div class="modal-top" style="background: linear-gradient(180deg, ${stemColor.dark}, var(--bg-card))">
                <div class="modal-symbol">${stem.symbol}</div>
                <div class="modal-char">${CHEONGAN[stemIdx]}${JIJI[branchIdx]}</div>
                <div class="modal-hanja">${stem.hanja}${branch.hanja}</div>
            </div>

            <div class="modal-body">
                <h3 class="modal-title" style="color: ${stemColor.light}">${stem.title} + ${branch.title}</h3>

                <div class="modal-badges">
                    <span class="modal-badge" style="background: ${stemColor.main}">${stemOheng}(${OHENG_SYMBOLS[stemOheng]}) ${stemYY}</span>
                    <span class="modal-badge" style="background: ${branchColor.main}">${branchOheng}(${OHENG_SYMBOLS[branchOheng]}) ${branchYY}</span>
                </div>

                <!-- 천간 -->
                <div class="combo-detail-section">
                    <div class="cds-header">
                        <span class="cds-icon">${stem.symbol}</span>
                        <span class="cds-label">천간</span>
                        <span class="cds-name" style="color:${stemColor.main}">${CHEONGAN[stemIdx]}(${stem.hanja}) · ${stem.title}</span>
                    </div>
                    <p class="cds-desc">${stem.description}</p>
                    <div class="modal-keywords" style="margin-top:8px">
                        ${stem.keywords.map(k => `<span class="modal-kw" style="border-color:${stemColor.main}40;color:${stemColor.light}">${k}</span>`).join('')}
                    </div>
                </div>

                <!-- 지지 -->
                <div class="combo-detail-section">
                    <div class="cds-header">
                        <span class="cds-icon">${branch.symbol}</span>
                        <span class="cds-label">지지</span>
                        <span class="cds-name" style="color:${branchColor.main}">${JIJI[branchIdx]}(${branch.hanja}) · ${branch.title}</span>
                    </div>
                    <p class="cds-desc">${branch.description}</p>
                    <div class="modal-keywords" style="margin-top:8px">
                        ${branch.keywords.map(k => `<span class="modal-kw" style="border-color:${branchColor.main}40;color:${branchColor.light}">${k}</span>`).join('')}
                    </div>
                </div>

                <!-- 오행 관계 -->
                <div class="modal-section">
                    <h4>오행 관계</h4>
                    <div class="combo-oheng-visual">
                        <span class="cov-item" style="color:${stemColor.main}">${OHENG_SYMBOLS[stemOheng]} ${stemOheng}</span>
                        <span class="cov-arrow">⟷</span>
                        <span class="cov-item" style="color:${branchColor.main}">${OHENG_SYMBOLS[branchOheng]} ${branchOheng}</span>
                    </div>
                    <p style="font-size:0.85rem;color:var(--text-secondary);line-height:1.6;margin-top:8px">${relation}</p>
                </div>
            </div>
        </div>
    `;

    document.getElementById('card-modal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function openCardModal(type, index) {
    const card = type === 'cheongan' ? CHEONGAN_CARDS[index] : JIJI_CARDS[index];
    const color = OHENG_COLORS[card.element];
    const char = type === 'cheongan' ? CHEONGAN[index] : JIJI[index];
    const typeLabel = type === 'cheongan' ? '천간' : '지지';
    const yinyang = type === 'cheongan' ? YINYANG_OF_CHEONGAN[index] : YINYANG_OF_JIJI[index];

    let extraInfo = '';
    if (type === 'jiji') {
        extraInfo = `
            <div class="modal-extra">
                <span class="me-label">동물</span>
                <span class="me-value">${card.symbol} ${card.animal}</span>
            </div>
        `;
    }
    if (type === 'cheongan') {
        extraInfo = `
            <div class="modal-extra">
                <span class="me-label">자연물</span>
                <span class="me-value">${card.subtitle}</span>
            </div>
        `;
    }

    const content = document.getElementById('card-modal-content');
    content.innerHTML = `
        <div class="modal-card" style="--mc-color: ${color.main}; --mc-light: ${color.light}; --mc-dark: ${color.dark}">
            <button class="modal-close" onclick="closeCardModal()">&times;</button>

            <div class="modal-top" style="background: linear-gradient(180deg, ${color.dark}, var(--bg-card))">
                <div class="modal-symbol">${card.symbol}</div>
                <div class="modal-char">${char}</div>
                <div class="modal-hanja">${card.hanja}</div>
            </div>

            <div class="modal-body">
                <h3 class="modal-title" style="color: ${color.light}">${card.title}</h3>

                <div class="modal-badges">
                    <span class="modal-badge" style="background: ${color.main}">${card.element} (${OHENG_SYMBOLS[card.element]})</span>
                    <span class="modal-badge">${yinyang}</span>
                    <span class="modal-badge">${typeLabel}</span>
                </div>

                ${extraInfo}

                <div class="modal-section">
                    <h4>카드 설명</h4>
                    <p>${card.description}</p>
                </div>

                <div class="modal-section">
                    <h4>키워드</h4>
                    <div class="modal-keywords">
                        ${card.keywords.map(k => `<span class="modal-kw" style="border-color: ${color.main}40; color: ${color.light}">${k}</span>`).join('')}
                    </div>
                </div>

                <div class="modal-section">
                    <h4>오행 관계</h4>
                    <div class="modal-relations">
                        <div class="mr-item">
                            <span class="mr-label">생(生)</span>
                            <span class="mr-arrow">→</span>
                            <span class="mr-value" style="color: ${OHENG_COLORS[PRODUCES[card.element]].main}">${PRODUCES[card.element]} (${OHENG_SYMBOLS[PRODUCES[card.element]]})</span>
                        </div>
                        <div class="mr-item">
                            <span class="mr-label">극(剋)</span>
                            <span class="mr-arrow">→</span>
                            <span class="mr-value" style="color: ${OHENG_COLORS[OVERCOMES[card.element]].main}">${OVERCOMES[card.element]} (${OHENG_SYMBOLS[OVERCOMES[card.element]]})</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById('card-modal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeCardModal(e) {
    if (e && e.target !== e.currentTarget) return;
    document.getElementById('card-modal').classList.remove('open');
    document.body.style.overflow = '';
}

// 파티클 배경 효과
function initParticles() {
    const canvas = document.getElementById('particles');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    const particles = [];
    for (let i = 0; i < 50; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: Math.random() * 2 + 0.5,
            speedX: (Math.random() - 0.5) * 0.3,
            speedY: (Math.random() - 0.5) * 0.3,
            opacity: Math.random() * 0.5 + 0.2
        });
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.x += p.speedX;
            p.y += p.speedY;
            if (p.x < 0) p.x = canvas.width;
            if (p.x > canvas.width) p.x = 0;
            if (p.y < 0) p.y = canvas.height;
            if (p.y > canvas.height) p.y = 0;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(212, 175, 55, ${p.opacity})`;
            ctx.fill();
        });
        requestAnimationFrame(animate);
    }
    animate();
}
